/**
 * Created by Febie on 26/03/2017.
 */
public interface IDable {

    public void setId ();
    public String getId();

}
