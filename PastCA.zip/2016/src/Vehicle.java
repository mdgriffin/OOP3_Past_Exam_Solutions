/**
 * Created by Febie on 26/03/2017.
 */
public abstract class Vehicle implements IDable {

    public static int num = 0; /* The ‘num’ class
                                   variable is incremented every time a subclass of the Vehicle class is
                                   instantiated*/

    private int passengerNum;
    private String type;

    public Vehicle(String type, int passengerNum) {
        setPassengerNum(passengerNum);
        setType(type);

        num++;   /* The ‘num’ class
                    variable is incremented every time a subclass of the Vehicle class is
                    instantiated*/
    }

    public int getPassengerNum() {
        return passengerNum;
    }

    public void setPassengerNum(int passengerNum) {
        this.passengerNum = passengerNum;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "Type: " + getType() + "\nNumber of Passengers: " + getPassengerNum();
    }
}
