package mdgriffin.me.pastExam2015;

public interface IDable {

    public void setId (String id);

}
