package mdgriffin.me.pastExam2016;

public interface IDable {

    public void setId ();
    public String getId();

}
