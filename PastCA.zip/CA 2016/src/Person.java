/**
 * Created by t00187715 on 27/03/2017.
 */
public interface Person {
    public String getName();
    public  int getAge();
    public  void setName(String name);
    public  void setAge(int age);
}
